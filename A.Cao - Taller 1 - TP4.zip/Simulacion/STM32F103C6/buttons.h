#include <stm32f103x6.h>

void buttons_init(void);
uint8_t button_press(void);
void button_release(void);
